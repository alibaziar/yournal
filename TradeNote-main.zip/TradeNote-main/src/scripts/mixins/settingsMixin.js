const settingsMixin = {
    methods: {
    }
}